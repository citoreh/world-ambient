// World Ambient — popup UI

const $ = (id) => document.getElementById(id);
const select = $("playlistSelect");
const playBtn = $("playBtn");
const nextBtn = $("nextBtn");
const refreshBtn = $("refreshBtn");
const volume = $("volume");
const orb = $("orb");
const nowArea = $("nowArea");
const nowLabel = $("nowLabel");
const nowTitle = $("nowTitle");
const status = $("status");
const iconPlay = $("iconPlay");
const iconPause = $("iconPause");

// Block save/download affordances inside the popup itself
document.addEventListener("contextmenu", (e) => e.preventDefault());

function send(msg) {
  return chrome.runtime.sendMessage(msg);
}

// ---------- skins
const THEMES = ["dusk", "dawn", "forest", "sea", "noir"];

function applyTheme(theme) {
  if (!THEMES.includes(theme)) theme = "dusk";
  document.body.dataset.theme = theme;
  document.querySelectorAll(".swatch").forEach((b) => {
    b.classList.toggle("active", b.dataset.theme === theme);
  });
}

document.querySelectorAll(".swatch").forEach((b) => {
  b.addEventListener("click", () => {
    applyTheme(b.dataset.theme);
    chrome.storage.local.set({ wa_theme: b.dataset.theme });
  });
});

chrome.storage.local.get("wa_theme").then(({ wa_theme }) => applyTheme(wa_theme || "dusk"));

// ---------- render
function render(s) {
  if (!s) return;

  // playlists — titles arrive alphabetized from the background, "All" first
  if (s.titles && s.titles.length) {
    select.innerHTML = "";
    for (const t of s.titles) {
      const opt = document.createElement("option");
      opt.value = t;
      opt.textContent = t;
      select.appendChild(opt);
    }
    select.value = s.currentTitle || s.titles[0];
  }

  const ready = Boolean(s.currentTitle);
  playBtn.disabled = !ready;
  nextBtn.disabled = !ready;

  iconPlay.hidden = s.isPlaying;
  iconPause.hidden = !s.isPlaying;
  playBtn.setAttribute("aria-label", s.isPlaying ? "Pause" : "Play");
  orb.classList.toggle("playing", Boolean(s.isPlaying));

  // now playing + hover tooltip with the actual track name
  if (s.currentTrack) {
    nowLabel.textContent = s.isPlaying ? "Now drifting through" : "Paused in";
    nowTitle.textContent = s.currentTrack.title;
    const trackName = s.currentTrack.name || s.currentTrack.id || "";
    const tip = trackName ? `Now playing: ${trackName}` : "";
    nowArea.title = tip;
    orb.title = tip;
  } else if (s.currentTitle) {
    nowLabel.textContent = "Ready to play";
    nowTitle.textContent = s.currentTitle;
    nowArea.title = "";
    orb.title = "";
  } else {
    nowLabel.textContent = "Choose a place to begin";
    nowTitle.innerHTML = "&nbsp;";
    nowArea.title = "";
    orb.title = "";
  }

  volume.value = Math.round((s.volume ?? 0.8) * 100);

  if (s.error) {
    status.textContent = s.error;
    status.classList.add("error");
  } else {
    status.textContent = "";
    status.classList.remove("error");
  }
}

// ---------- events
select.addEventListener("change", async () => {
  const s = await send({ type: "SELECT_PLAYLIST", title: select.value, autoplay: true });
  render(s);
});

playBtn.addEventListener("click", async () => {
  render(await send({ type: "TOGGLE_PLAY" }));
});

nextBtn.addEventListener("click", async () => {
  render(await send({ type: "NEXT" }));
});

volume.addEventListener("input", async () => {
  await send({ type: "SET_VOLUME", volume: volume.value / 100 });
});

refreshBtn.addEventListener("click", async () => {
  status.textContent = "Reloading playlists…";
  render(await send({ type: "REFRESH" }));
});

$("adminBtn").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("admin.html") });
});

// live updates from background (e.g., track auto-advances while popup is open)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.target === "popup" && msg.type === "STATE") render(msg.state);
});

// version tooltip — hover the wordmark to confirm which build is running
document.querySelector(".wordmark").title = `World Ambient v${chrome.runtime.getManifest().version}`;

// click an error message to dismiss it
status.style.cursor = "pointer";
status.addEventListener("click", async () => {
  if (status.classList.contains("error")) render(await send({ type: "CLEAR_ERROR" }));
});

// ---------- init
(async () => {
  render(await send({ type: "GET_STATE" }));
})();
