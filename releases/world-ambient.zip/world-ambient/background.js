// World Ambient — background service worker
// Owns: CSV data, playlist state, shuffle queue, offscreen audio lifecycle.

const FIREBASE = {
  apiKey: "AIzaSyDNwbgZaS6uwvpYbbtir95n8folKvXUsm8",
  projectId: "ambience-ba0f5",
};
const FS_DOCS = `https://firestore.googleapis.com/v1/projects/${FIREBASE.projectId}/databases/(default)/documents`;

const OFFSCREEN_URL = "offscreen.html";
const ALL_TITLE = "All";

// Wipe stale state whenever the extension is installed or updated,
// so cached playlists/errors from an old version never survive.
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.session.remove("wa_state").catch(() => {});
  state.playlists = {};
  state.titles = [];
  state.dataLoadedAt = 0;
  state.error = null;
});

// ---------- in-memory state (mirrored to storage.session so it survives SW restarts)
let state = {
  playlists: {},        // { title: [ {id, title, url}, ... ] }
  titles: [],           // ordered unique titles
  currentTitle: null,
  currentTrack: null,   // {id, title, url}
  queue: [],            // shuffled indices remaining for currentTitle
  lastIndex: -1,        // index of last played track (to avoid immediate repeat)
  isPlaying: false,
  volume: 0.8,
  dataLoadedAt: 0,
  error: null,
};

let stateLoaded = null; // promise guard

async function loadState() {
  if (!stateLoaded) {
    stateLoaded = (async () => {
      const s = await chrome.storage.session.get("wa_state");
      if (s.wa_state) state = { ...state, ...s.wa_state };
      const local = await chrome.storage.local.get(["wa_volume", "wa_lastTitle"]);
      if (typeof local.wa_volume === "number") state.volume = local.wa_volume;
      if (!state.currentTitle && local.wa_lastTitle) state.currentTitle = local.wa_lastTitle;
    })();
  }
  return stateLoaded;
}

async function saveState() {
  await chrome.storage.session.set({ wa_state: state });
}

// ---------- URL normalization
// Share links from Drive/Dropbox point at HTML pages, not audio files.
// Convert them to direct-download forms an <audio> element can play.
function normalizeUrl(url) {
  try {
    const u = new URL(url);

    // Google Drive: /file/d/FILE_ID/view  or  open?id=FILE_ID  or  uc?id=FILE_ID
    if (u.hostname === "drive.google.com" || u.hostname === "docs.google.com") {
      let id = null;
      const m = u.pathname.match(/\/file\/d\/([^/]+)/) || u.pathname.match(/\/d\/([^/]+)/);
      if (m) id = m[1];
      if (!id) id = u.searchParams.get("id");
      if (id) return `https://drive.google.com/uc?export=download&id=${id}`;
    }

    // Dropbox: force raw file
    if (u.hostname === "www.dropbox.com" || u.hostname === "dropbox.com") {
      u.hostname = "dl.dropboxusercontent.com";
      u.searchParams.delete("dl");
      return u.toString();
    }

    return url;
  } catch {
    return url;
  }
}

// ---------- Bunny Stream (mediadelivery.net) resolver
// player.mediadelivery.net/play/LIB/GUID is an HTML player page.
// Fetch the embed page and extract the real stream: prefer an MP4
// fallback (plays natively), otherwise the HLS playlist (via hls.js).
const bunnyCache = new Map(); // originalUrl -> resolved stream URL

function isBunnyUrl(url) {
  return /https:\/\/(player|iframe|video)\.mediadelivery\.net\/(play|embed)\//i.test(url);
}

async function urlExists(url) {
  try {
    const r = await fetch(url, { method: "GET", headers: { Range: "bytes=0-1" }, cache: "no-store" });
    return r.ok || r.status === 206;
  } catch {
    return false;
  }
}

async function resolveBunny(url) {
  if (bunnyCache.has(url)) return bunnyCache.get(url);
  const m = url.match(/mediadelivery\.net\/(?:play|embed)\/(\d+)\/([a-zA-Z0-9-]+)/);
  if (!m) return url;
  const [, lib, guid] = m;
  try {
    let html = null;
    for (const host of ["iframe.mediadelivery.net", "player.mediadelivery.net"]) {
      try {
        const res = await fetch(`https://${host}/embed/${lib}/${guid}`, { cache: "no-store" });
        if (res.ok) { html = await res.text(); break; }
      } catch { /* try next host */ }
    }
    if (!html) throw new Error("could not load the embed page");

    // Track name from the embed page metadata (e.g. "Ambient iran 1.mp3")
    let name = null;
    const og = html.match(/property="og:title"\s+content="([^"]+)"/) || html.match(/<title>([^<]+)<\/title>/);
    if (og) name = og[1].replace(/\.(mp3|m4a|wav|flac|ogg|aac|mp4)$/i, "").trim();

    html = html.replace(/\\\//g, "/"); // unescape JSON-embedded URLs

    // Collect candidate stream URLs, best-first
    const candidates = [];
    const mp4s = [...html.matchAll(/https:\/\/[a-zA-Z0-9.-]+\/[a-zA-Z0-9-]+\/play_(\d+)p\.mp4/g)];
    mp4s.sort((a, b) => Number(a[1]) - Number(b[1]));
    for (const x of mp4s) candidates.push(x[0]);

    const hls = html.match(/https:\/\/[a-zA-Z0-9.-]+\/[a-zA-Z0-9-]+\/playlist\.m3u8[^"'\s\\]*/);
    if (hls) candidates.push(hls[0]);

    const host = html.match(/https:\/\/(vz-[a-zA-Z0-9.-]+\.b-cdn\.net)/);
    if (host) {
      const constructed = `https://${host[1]}/${guid}/playlist.m3u8`;
      if (!candidates.includes(constructed)) candidates.push(constructed);
    }

    if (!candidates.length) {
      throw new Error("no stream URL found in the player page (the video may be private or token-protected)");
    }

    // Verify before trusting — embed pages can advertise files that don't exist
    for (const c of candidates) {
      if (await urlExists(c)) {
        const resolved = { url: c, name };
        bunnyCache.set(url, resolved);
        return resolved;
      }
    }
    throw new Error(`stream URLs found but none are accessible (tried ${candidates[0]}) — check token authentication / direct URL blocking in the Bunny library settings`);
  } catch (e) {
    throw new Error(`Bunny Stream: ${e.message}`);
  }
}

async function fetchData(force = false) {
  await loadState();
  // cache for 10 minutes unless forced
  if (!force && state.titles.length && Date.now() - state.dataLoadedAt < 10 * 60 * 1000) {
    // data is present and fresh — a lingering fetch error is stale by definition
    if (state.error && /Sheet|Firestore returned|denied read/.test(state.error)) {
      state.error = null;
      await saveState();
    }
    return;
  }
  try {
    // Read all docs from the "tracks" collection (public read via security rules)
    const docs = [];
    let pageToken = null;
    do {
      const u = new URL(`${FS_DOCS}/tracks`);
      u.searchParams.set("pageSize", "300");
      if (pageToken) u.searchParams.set("pageToken", pageToken);
      const res = await fetch(u.toString(), { cache: "no-store" });
      if (res.status === 403) throw new Error("Firestore denied read access — check the security rules allow public read on /tracks");
      if (!res.ok) throw new Error(`Firestore returned ${res.status}`);
      const j = await res.json();
      docs.push(...(j.documents || []));
      pageToken = j.nextPageToken || null;
    } while (pageToken);

    const playlists = {};
    const titles = [];
    const allTracks = [];
    for (const doc of docs) {
      const f = doc.fields || {};
      const title = (f.title?.stringValue || "").trim();
      const url = (f.url?.stringValue || "").trim();
      if (!title || !/^https?:\/\//i.test(url)) continue;
      if (!playlists[title]) { playlists[title] = []; titles.push(title); }
      const track = {
        id: (f.id?.stringValue || "").trim(),
        title,
        url: normalizeUrl(url),
      };
      playlists[title].push(track);
      allTracks.push(track);
    }
    if (!titles.length) throw new Error("No tracks in Firestore yet — open the admin page to add some");

    titles.sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));

    // Synthetic "All" playlist, always first (unless a real one exists)
    if (!playlists[ALL_TITLE]) {
      playlists[ALL_TITLE] = allTracks;
      titles.unshift(ALL_TITLE);
    }

    state.playlists = playlists;
    state.titles = titles;
    state.dataLoadedAt = Date.now();
    state.error = null;
    if (state.currentTitle && !playlists[state.currentTitle]) {
      state.currentTitle = null;
      state.queue = [];
    }
  } catch (e) {
    state.error = e.message || "Could not load tracks from Firestore";
  }
  await saveState();
}

// ---------- shuffle queue (random within a title, no immediate repeats)
function refillQueue() {
  const tracks = state.playlists[state.currentTitle] || [];
  const idx = tracks.map((_, i) => i);
  for (let i = idx.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [idx[i], idx[j]] = [idx[j], idx[i]];
  }
  // avoid playing the same track twice in a row across refills
  if (idx.length > 1 && idx[0] === state.lastIndex) {
    [idx[0], idx[idx.length - 1]] = [idx[idx.length - 1], idx[0]];
  }
  state.queue = idx;
}

function nextTrack() {
  const tracks = state.playlists[state.currentTitle] || [];
  if (!tracks.length) return null;
  if (!state.queue.length) refillQueue();
  const i = state.queue.shift();
  state.lastIndex = i;
  return tracks[i];
}

// ---------- offscreen document
let creatingOffscreen = null;
async function ensureOffscreen() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_URL)],
  });
  if (contexts.length > 0) return;
  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Keep ambient music playing while the popup is closed",
    }).finally(() => { creatingOffscreen = null; });
  }
  await creatingOffscreen;
}

async function offscreenSend(msg) {
  await ensureOffscreen();
  return chrome.runtime.sendMessage({ target: "offscreen", ...msg });
}

// ---------- playback commands
let consecutiveErrors = 0;

async function playNext() {
  const track = nextTrack();
  if (!track) return;

  let streamUrl = track.url;
  let name = null;
  if (isBunnyUrl(streamUrl)) {
    try {
      const r = await resolveBunny(streamUrl);
      streamUrl = r.url;
      name = r.name;
    } catch (e) {
      state.error = e.message;
      state.isPlaying = false;
      await saveState();
      broadcast();
      return;
    }
  } else {
    // best-effort name from the URL filename
    try {
      const seg = new URL(streamUrl).pathname.split("/").filter(Boolean).pop() || "";
      name = decodeURIComponent(seg).replace(/\.(mp3|m4a|wav|flac|ogg|aac|mp4|m3u8)$/i, "") || null;
    } catch { /* keep null */ }
  }

  state.currentTrack = { ...track, name: name || track.id || null };
  state.isPlaying = true;
  await saveState();
  await offscreenSend({ type: "PLAY", url: streamUrl, volume: state.volume });
  broadcast();
}

async function selectPlaylist(title, autoplay) {
  await fetchData();
  if (!state.playlists[title]) return;
  state.currentTitle = title;
  state.lastIndex = -1;
  state.error = null;
  consecutiveErrors = 0;
  refillQueue();
  chrome.storage.local.set({ wa_lastTitle: title });
  if (autoplay) await playNext();
  else { await saveState(); broadcast(); }
}

async function togglePlay() {
  if (!state.currentTrack) {
    if (state.currentTitle) await playNext();
    return;
  }
  if (state.isPlaying) {
    state.isPlaying = false;
    await saveState();
    await offscreenSend({ type: "PAUSE" });
  } else {
    state.isPlaying = true;
    await saveState();
    await offscreenSend({ type: "RESUME" });
  }
  broadcast();
}

function broadcast() {
  chrome.runtime.sendMessage({ target: "popup", type: "STATE", state: publicState() }).catch(() => {});
}

function publicState() {
  return {
    titles: state.titles,
    counts: Object.fromEntries(state.titles.map(t => [t, state.playlists[t].length])),
    currentTitle: state.currentTitle,
    currentTrack: state.currentTrack,
    isPlaying: state.isPlaying,
    volume: state.volume,
    error: state.error,
  };
}

// ---------- message router
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    await loadState();
    switch (msg.type) {
      case "GET_STATE":
        await fetchData();
        // default preset: "All" when the user hasn't chosen a playlist
        if (!state.currentTitle && state.playlists[ALL_TITLE]) {
          state.currentTitle = ALL_TITLE;
          state.lastIndex = -1;
          refillQueue();
          await saveState();
        }
        sendResponse(publicState());
        break;
      case "REFRESH":
        await fetchData(true);
        sendResponse(publicState());
        break;
      case "SELECT_PLAYLIST":
        await selectPlaylist(msg.title, msg.autoplay);
        sendResponse(publicState());
        break;
      case "TOGGLE_PLAY":
        await togglePlay();
        sendResponse(publicState());
        break;
      case "NEXT":
        if (state.currentTitle) await playNext();
        sendResponse(publicState());
        break;
      case "CLEAR_ERROR":
        state.error = null;
        await saveState();
        sendResponse(publicState());
        break;
      case "SET_VOLUME":
        state.volume = msg.volume;
        chrome.storage.local.set({ wa_volume: msg.volume });
        await saveState();
        offscreenSend({ type: "VOLUME", volume: msg.volume }).catch(() => {});
        sendResponse(publicState());
        break;
      // from offscreen
      case "TRACK_STARTED":
        consecutiveErrors = 0;
        state.error = null;
        await saveState();
        broadcast();
        sendResponse(true);
        break;
      case "TRACK_ENDED":
        await playNext();
        sendResponse(true);
        break;
      case "TRACK_ERROR": {
        consecutiveErrors++;
        const playlistSize = (state.playlists[state.currentTitle] || []).length;
        if (consecutiveErrors >= Math.min(4, Math.max(2, playlistSize))) {
          // every attempt is failing — stop and explain instead of looping
          state.isPlaying = false;
          const where = msg.url ? ` [${msg.url.slice(0, 90)}]` : "";
          state.error = `Can't play — ${msg.detail || "tracks failed to load"}.${where}`;
          await saveState();
          offscreenSend({ type: "STOP" }).catch(() => {});
          broadcast();
        } else {
          await playNext();
        }
        sendResponse(true);
        break;
      }
      case "OFFSCREEN_PAUSED_EXTERNALLY":
        state.isPlaying = false;
        await saveState();
        broadcast();
        sendResponse(true);
        break;
      default:
        sendResponse(null);
    }
  })();
  return true; // async response
});
