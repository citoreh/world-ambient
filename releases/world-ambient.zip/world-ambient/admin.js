// World Ambient — admin page.
// Talks to Firebase via REST (no SDK needed inside an extension):
//   Auth:      identitytoolkit.googleapis.com (sign-in) + securetoken.googleapis.com (refresh)
//   Firestore: firestore.googleapis.com "tracks" collection

const FIREBASE = {
  apiKey: "AIzaSyDNwbgZaS6uwvpYbbtir95n8folKvXUsm8",
  projectId: "ambience-ba0f5",
};
const FS_DOCS = `https://firestore.googleapis.com/v1/projects/${FIREBASE.projectId}/databases/(default)/documents`;

const $ = (id) => document.getElementById(id);

// ================= auth =================
let auth = null; // { idToken, refreshToken, expiresAt, email }

async function loadAuth() {
  const { wa_auth } = await chrome.storage.local.get("wa_auth");
  auth = wa_auth || null;
}
async function saveAuth() {
  await chrome.storage.local.set({ wa_auth: auth });
}

async function signIn(email, password) {
  const res = await fetch(
    `https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${FIREBASE.apiKey}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, returnSecureToken: true }),
    }
  );
  const j = await res.json();
  if (!res.ok) {
    const code = j.error?.message || "SIGN_IN_FAILED";
    const friendly = {
      EMAIL_NOT_FOUND: "No account with that email",
      INVALID_PASSWORD: "Wrong password",
      INVALID_LOGIN_CREDENTIALS: "Wrong email or password",
      USER_DISABLED: "This account is disabled",
      "PASSWORD_LOGIN_DISABLED": "Email/password sign-in is not enabled in Firebase → Authentication → Sign-in method",
    }[code] || code;
    throw new Error(friendly);
  }
  auth = {
    idToken: j.idToken,
    refreshToken: j.refreshToken,
    expiresAt: Date.now() + (Number(j.expiresIn) - 60) * 1000,
    email: j.email,
  };
  await saveAuth();
}

async function freshToken() {
  if (!auth) throw new Error("Not signed in");
  if (Date.now() < auth.expiresAt) return auth.idToken;
  const res = await fetch(`https://securetoken.googleapis.com/v1/token?key=${FIREBASE.apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(auth.refreshToken)}`,
  });
  const j = await res.json();
  if (!res.ok) {
    auth = null;
    await saveAuth();
    throw new Error("Session expired — please sign in again");
  }
  auth.idToken = j.id_token;
  auth.refreshToken = j.refresh_token;
  auth.expiresAt = Date.now() + (Number(j.expires_in) - 60) * 1000;
  await saveAuth();
  return auth.idToken;
}

async function signOut() {
  auth = null;
  await saveAuth();
  renderAuth();
}

// ================= firestore =================
function toDoc(track) {
  return {
    fields: {
      id: { stringValue: track.id || "" },
      title: { stringValue: track.title },
      url: { stringValue: track.url },
    },
  };
}
function fromDoc(doc) {
  const f = doc.fields || {};
  return {
    docName: doc.name, // full resource path, used for update/delete
    id: f.id?.stringValue || "",
    title: f.title?.stringValue || "",
    url: f.url?.stringValue || "",
  };
}

async function listTracks() {
  const out = [];
  let pageToken = null;
  do {
    const u = new URL(`${FS_DOCS}/tracks`);
    u.searchParams.set("pageSize", "300");
    if (pageToken) u.searchParams.set("pageToken", pageToken);
    const res = await fetch(u.toString(), { cache: "no-store" });
    if (!res.ok) throw new Error(`Firestore read failed (${res.status}) — check security rules`);
    const j = await res.json();
    for (const d of j.documents || []) out.push(fromDoc(d));
    pageToken = j.nextPageToken || null;
  } while (pageToken);
  return out;
}

async function authedFetch(url, options = {}) {
  const token = await freshToken();
  const res = await fetch(url, {
    ...options,
    headers: { ...(options.headers || {}), Authorization: `Bearer ${token}` },
  });
  if (res.status === 401 || res.status === 403) {
    throw new Error("Firestore rejected the write — check that the rules allow writes for signed-in users");
  }
  if (!res.ok) throw new Error(`Firestore returned ${res.status}`);
  return res;
}

async function addTrack(track) {
  await authedFetch(`${FS_DOCS}/tracks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(toDoc(track)),
  });
}

async function updateTrack(docName, track) {
  const u = new URL(`https://firestore.googleapis.com/v1/${docName}`);
  for (const f of ["id", "title", "url"]) u.searchParams.append("updateMask.fieldPaths", f);
  await authedFetch(u.toString(), {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(toDoc(track)),
  });
}

async function deleteTrack(docName) {
  await authedFetch(`https://firestore.googleapis.com/v1/${docName}`, { method: "DELETE" });
}

// Batch-write for the importer (max 500 writes per commit)
async function commitBatch(tracks) {
  const writes = tracks.map((t) => ({
    update: {
      name: `projects/${FIREBASE.projectId}/databases/(default)/documents/tracks/${crypto.randomUUID()}`,
      ...toDoc(t),
    },
  }));
  await authedFetch(`${FS_DOCS.replace("/documents", "")}/documents:commit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ writes }),
  });
}

// ================= CSV import =================
function parseCSV(text) {
  const rows = [];
  let row = [], field = "", inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else inQuotes = false;
      } else field += c;
    } else {
      if (c === '"') inQuotes = true;
      else if (c === ",") { row.push(field); field = ""; }
      else if (c === "\n" || c === "\r") {
        if (c === "\r" && text[i + 1] === "\n") i++;
        row.push(field); field = "";
        if (row.some(v => v.trim() !== "")) rows.push(row);
        row = [];
      } else field += c;
    }
  }
  row.push(field);
  if (row.some(v => v.trim() !== "")) rows.push(row);
  return rows;
}

async function importCsv(pastedText) {
  if (!pastedText || !pastedText.trim()) throw new Error("Paste some rows first");
  // Cells copied straight from a spreadsheet arrive tab-separated
  const text = pastedText.includes("\t") ? pastedText.replace(/\t/g, ",") : pastedText;
  const rows = parseCSV(text);
  if (!rows.length) throw new Error("No CSV data found");

  const header = rows[0].map((h) => h.trim().toLowerCase());
  let idCol = header.indexOf("id");
  let titleCol = header.indexOf("title");
  let urlCol = header.indexOf("url");
  let dataRows;
  if (titleCol !== -1 && urlCol !== -1) {
    dataRows = rows.slice(1);
  } else {
    idCol = 0; titleCol = 1; urlCol = 2;
    dataRows = rows;
  }
  if (idCol === -1) idCol = 0;

  const tracks = [];
  for (const r of dataRows) {
    const title = (r[titleCol] || "").trim();
    const trackUrl = (r[urlCol] || "").trim();
    if (!title || !/^https?:\/\//i.test(trackUrl)) continue;
    tracks.push({ id: (r[idCol] || "").trim(), title, url: trackUrl });
  }
  if (!tracks.length) throw new Error("No valid rows found");

  for (let i = 0; i < tracks.length; i += 400) {
    await commitBatch(tracks.slice(i, i + 400));
  }
  return tracks.length;
}

// ================= UI =================
let tracks = [];

function setMsg(el, text, cls) {
  el.textContent = text || "";
  el.className = "msg" + (cls ? ` ${cls}` : "");
}

function renderAuth() {
  const box = $("authBox");
  if (auth) {
    box.innerHTML = "";
    const span = document.createElement("span");
    span.textContent = auth.email;
    const btn = document.createElement("button");
    btn.textContent = "Sign out";
    btn.addEventListener("click", signOut);
    box.append(span, btn);
    $("signinCard").hidden = true;
    $("editor").hidden = false;
  } else {
    box.innerHTML = "";
    $("signinCard").hidden = false;
    $("editor").hidden = true;
  }
}

function renderTracks() {
  const table = $("trackTable");
  table.innerHTML = "";
  $("trackCount").textContent = tracks.length ? `· ${tracks.length}` : "";

  // update the datalist of existing titles
  const titles = [...new Set(tracks.map((t) => t.title))].sort((a, b) =>
    a.localeCompare(b, undefined, { sensitivity: "base" })
  );
  $("titleList").innerHTML = "";
  for (const t of titles) {
    const o = document.createElement("option");
    o.value = t;
    $("titleList").appendChild(o);
  }

  for (const title of titles) {
    const h = document.createElement("p");
    h.className = "group-title";
    h.textContent = title;
    table.appendChild(h);

    for (const t of tracks.filter((x) => x.title === title)) {
      table.appendChild(trackRow(t));
    }
  }
}

function trackRow(t) {
  const row = document.createElement("div");
  row.className = "track-row";

  const id = document.createElement("span");
  id.className = "track-id";
  id.textContent = t.id || "—";

  const url = document.createElement("span");
  url.className = "track-url";
  url.textContent = t.url;
  url.title = t.url;

  const actions = document.createElement("div");
  actions.className = "row-actions";
  const editBtn = document.createElement("button");
  editBtn.textContent = "Edit";
  const delBtn = document.createElement("button");
  delBtn.textContent = "Delete";
  delBtn.className = "danger";
  actions.append(editBtn, delBtn);

  row.append(id, url, actions);

  delBtn.addEventListener("click", async () => {
    if (delBtn.textContent === "Delete") {
      delBtn.textContent = "Sure?";
      setTimeout(() => { delBtn.textContent = "Delete"; }, 2500);
      return;
    }
    try {
      delBtn.disabled = true;
      await deleteTrack(t.docName);
      await reload();
      notifyPlayer();
    } catch (e) {
      setMsg($("globalMsg"), e.message, "error");
      delBtn.disabled = false;
    }
  });

  editBtn.addEventListener("click", () => {
    row.classList.add("editing");
    row.innerHTML = "";
    const grid = document.createElement("div");
    grid.className = "edit-grid";

    const idIn = document.createElement("input");
    idIn.type = "text"; idIn.value = t.id; idIn.placeholder = "ID";
    const titleIn = document.createElement("input");
    titleIn.type = "text"; titleIn.value = t.title; titleIn.placeholder = "Playlist title";
    titleIn.setAttribute("list", "titleList");
    const urlIn = document.createElement("input");
    urlIn.type = "url"; urlIn.value = t.url; urlIn.placeholder = "https://…";

    const save = document.createElement("button");
    save.className = "primary"; save.textContent = "Save";
    const cancel = document.createElement("button");
    cancel.className = "ghost"; cancel.textContent = "Cancel";

    grid.append(idIn, titleIn, urlIn, save, cancel);
    row.appendChild(grid);

    cancel.addEventListener("click", () => renderTracks());
    save.addEventListener("click", async () => {
      const nt = { id: idIn.value.trim(), title: titleIn.value.trim(), url: urlIn.value.trim() };
      if (!nt.title || !/^https?:\/\//i.test(nt.url)) {
        setMsg($("globalMsg"), "A playlist title and a valid http(s) URL are required", "error");
        return;
      }
      try {
        save.disabled = true;
        await updateTrack(t.docName, nt);
        await reload();
        notifyPlayer();
        setMsg($("globalMsg"), "");
      } catch (e) {
        setMsg($("globalMsg"), e.message, "error");
        save.disabled = false;
      }
    });
  });

  return row;
}

async function reload() {
  tracks = await listTracks();
  renderTracks();
}

function notifyPlayer() {
  chrome.runtime.sendMessage({ type: "REFRESH" }).catch(() => {});
}

// ================= events =================
$("signinBtn").addEventListener("click", async () => {
  const btn = $("signinBtn");
  try {
    btn.disabled = true;
    setMsg($("signinMsg"), "Signing in…");
    await signIn($("email").value.trim(), $("password").value);
    setMsg($("signinMsg"), "");
    renderAuth();
    await reload();
  } catch (e) {
    setMsg($("signinMsg"), e.message, "error");
  } finally {
    btn.disabled = false;
  }
});
$("password").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("signinBtn").click();
});

$("addBtn").addEventListener("click", async () => {
  const t = {
    id: $("addId").value.trim(),
    title: $("addTitle").value.trim(),
    url: $("addUrl").value.trim(),
  };
  if (!t.title || !/^https?:\/\//i.test(t.url)) {
    setMsg($("addMsg"), "A playlist title and a valid http(s) URL are required", "error");
    return;
  }
  try {
    $("addBtn").disabled = true;
    await addTrack(t);
    $("addId").value = ""; $("addUrl").value = "";
    setMsg($("addMsg"), "Added", "ok");
    await reload();
    notifyPlayer();
  } catch (e) {
    setMsg($("addMsg"), e.message, "error");
  } finally {
    $("addBtn").disabled = false;
  }
});

$("importBtn").addEventListener("click", async () => {
  try {
    $("importBtn").disabled = true;
    setMsg($("importMsg"), "Importing…");
    const n = await importCsv($("csvPaste").value);
    setMsg($("importMsg"), `Imported ${n} tracks`, "ok");
    $("csvPaste").value = "";
    await reload();
    notifyPlayer();
  } catch (e) {
    setMsg($("importMsg"), e.message, "error");
  } finally {
    $("importBtn").disabled = false;
  }
});

$("reloadBtn").addEventListener("click", () => reload().catch((e) => setMsg($("globalMsg"), e.message, "error")));

// ================= init =================
(async () => {
  await loadAuth();
  renderAuth();
  if (auth) {
    try { await freshToken(); } catch { /* session expired; renderAuth below reflects it */ }
    renderAuth();
  }
  try { await reload(); } catch (e) { setMsg($("globalMsg"), e.message, "error"); }
})();
