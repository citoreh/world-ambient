// World Ambient — offscreen audio engine.
// A bare Audio object: no visible controls, so no native download affordance.

const audio = new Audio();
audio.preload = "auto";

let hls = null;
function destroyHls() {
  if (hls) { try { hls.destroy(); } catch {} hls = null; }
}

let fadeTimer = null;

function clearFade() {
  if (fadeTimer) { clearInterval(fadeTimer); fadeTimer = null; }
}

function fadeTo(target, ms = 600) {
  clearFade();
  const start = audio.volume;
  const steps = Math.max(1, Math.round(ms / 40));
  let n = 0;
  fadeTimer = setInterval(() => {
    n++;
    audio.volume = Math.min(1, Math.max(0, start + (target - start) * (n / steps)));
    if (n >= steps) clearFade();
  }, 40);
}

audio.addEventListener("ended", () => {
  chrome.runtime.sendMessage({ type: "TRACK_ENDED" }).catch(() => {});
});

audio.addEventListener("playing", () => {
  chrome.runtime.sendMessage({ type: "TRACK_STARTED" }).catch(() => {});
});

function describeError() {
  const codes = {
    1: "loading was aborted",
    2: "network error while loading",
    3: "file could not be decoded (not a valid audio file?)",
    4: "URL is not a playable audio source",
  };
  const code = audio.error && audio.error.code;
  return codes[code] || "unknown playback error";
}

audio.addEventListener("error", () => {
  if (hls) return; // hls.js reports its own errors with better detail
  chrome.runtime.sendMessage({
    type: "TRACK_ERROR",
    detail: describeError(),
    url: audio.src,
  }).catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== "offscreen") return;
  switch (msg.type) {
    case "PLAY": {
      clearFade();
      destroyHls();
      audio.volume = typeof msg.volume === "number" ? msg.volume : 0.8;

      if (/\.m3u8(\?|$)/i.test(msg.url)) {
        if (!(self.Hls && Hls.isSupported())) {
          chrome.runtime.sendMessage({
            type: "TRACK_ERROR",
            detail: `HLS engine unavailable (Hls=${typeof self.Hls}, MediaSource=${typeof self.MediaSource})`,
            url: msg.url,
          }).catch(() => {});
          sendResponse(true);
          break;
        }
        hls = new Hls({ maxBufferLength: 60 });
        hls.on(Hls.Events.ERROR, (evt, data) => {
          if (data.fatal) {
            const detail = `stream error (${data.details || data.type})`;
            destroyHls();
            chrome.runtime.sendMessage({ type: "TRACK_ERROR", detail, url: msg.url }).catch(() => {});
          }
        });
        hls.loadSource(msg.url);
        hls.attachMedia(audio);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          audio.play().catch((err) => {
            chrome.runtime.sendMessage({
              type: "TRACK_ERROR",
              detail: err && err.message ? err.message : "play() was rejected",
              url: msg.url,
            }).catch(() => {});
          });
        });
      } else {
        audio.src = msg.url;
        audio.play().catch((err) => {
          chrome.runtime.sendMessage({
            type: "TRACK_ERROR",
            detail: err && err.message ? err.message : "play() was rejected",
            url: audio.src,
          }).catch(() => {});
        });
      }
      sendResponse(true);
      break;
    }
    case "PAUSE":
      audio.pause();
      sendResponse(true);
      break;
    case "RESUME":
      audio.play().catch(() => {});
      sendResponse(true);
      break;
    case "VOLUME":
      fadeTo(msg.volume, 200);
      sendResponse(true);
      break;
    case "STOP":
      destroyHls();
      audio.pause();
      audio.removeAttribute("src");
      sendResponse(true);
      break;
    default:
      sendResponse(null);
  }
  return true;
});
